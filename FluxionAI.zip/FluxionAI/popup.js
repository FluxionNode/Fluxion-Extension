let micStream;

// Start microphone access
document.getElementById("start-mic").addEventListener("click", async () => {
  try {
    micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    document.getElementById("listening-status").innerText = "Microphone is active. Listening...";
    document.getElementById("stop-mic").disabled = false;
    document.getElementById("start-mic").disabled = true;
  } catch (error) {
    console.error("Error accessing microphone:", error);
    document.getElementById("listening-status").innerText = "Error: Cannot access microphone. Check permissions.";
  }
});

// Stop microphone access
document.getElementById("stop-mic").addEventListener("click", () => {
  if (micStream) {
    micStream.getTracks().forEach((track) => track.stop());
    micStream = null;
  }
  document.getElementById("listening-status").innerText = "Microphone stopped.";
  document.getElementById("start-mic").disabled = false;
  document.getElementById("stop-mic").disabled = true;
});

// Generate random Base58-style Solana address
function generateBase58Address(length = 44) {
  const chars = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  let address = "";
  for (let i = 0; i < length; i++) {
    address += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return address;
}

// Terminal lines for Solana-specific operations
const terminalLines = [
  "Initializing FluxionNode AI...",
  "Connecting to Solana RPC at https://api.mainnet-beta.solana.com...",
  "Fetching cluster version...",
  "Cluster version: 1.10.32",
  "Checking Solana validator health...",
  "Validator status: Healthy",
  "Fetching latest block height...",
  "Latest block height: 29,453,812",
  "Fetching slot details...",
  "Current slot: 1,029,843,122",
  "Syncing ledger data: Epoch 0...",
  `Downloading block data for wallet ${generateBase58Address()}...`,
  `Transaction ${generateBase58Address(10)} verified.`,
  `Transaction ${generateBase58Address(10)} flagged as suspicious (alert sent).`,
  `Program ${generateBase58Address()} audit pending: Potential risks detected.`,
  "Calculating Solana rewards distribution for Epoch 402...",
  "Rewards processed for 12,483 wallets.",
  "Syncing blocks: 25%",
  "Syncing blocks: 50%",
  "Syncing blocks: 75%",
  "Syncing blocks: 99%",
  "Finalizing ledger synchronization...",
  "Ledger sync complete.",
  "Launching Solana transaction monitoring service...",
  `Real-time transaction: Wallet ${generateBase58Address()} → Wallet ${generateBase58Address()} (2.4 SOL)`,
  `Real-time transaction: Wallet ${generateBase58Address()} → Program ${generateBase58Address()} (18.9 SOL)`,
  `Detected new staking operation: Wallet ${generateBase58Address()} staked 10 SOL.`,
  "Verifying account ownership...",
  `Account ${generateBase58Address()} ownership verified.`,
  "Node status: Operational",
  "Node successfully synced and ready for monitoring.",
];

let lineIndex = 0;

function updateTerminal() {
  if (lineIndex < terminalLines.length) {
    const newLine = document.createElement("p");
    newLine.textContent = terminalLines[lineIndex];
    document.getElementById("terminal-output").appendChild(newLine);
    lineIndex++;
    setTimeout(updateTerminal, 1000); // Add a delay for the next line
  }
}

updateTerminal();
