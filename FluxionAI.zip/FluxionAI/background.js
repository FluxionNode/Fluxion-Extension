console.log("FluxionNode AI background service worker running...");

// Listen for clipboard events
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "readClipboard") {
    navigator.clipboard.readText().then((text) => {
      console.log("Clipboard content:", text);
      sendResponse({ clipboardContent: text });
    });
    return true; // Required to keep the sendResponse callback active
  }
});

// Log when the extension is installed
chrome.runtime.onInstalled.addListener(() => {
  console.log("FluxionNode AI extension installed.");
});
